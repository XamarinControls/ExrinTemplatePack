﻿using $saferootprojectname$.Framework.Abstraction.ModelState;

namespace $safeprojectname$.ModelState
{
    public class AuthModelState : Exrin.Framework.ModelState, IAuthModelState
    {
    }
}
