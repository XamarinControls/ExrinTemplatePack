﻿using $saferootprojectname$.Framework.Abstraction.ModelState;

namespace $safeprojectname$.ModelState
{
    public class MainModelState : Exrin.Framework.ModelState, IMainModelState
    {
    }
}
