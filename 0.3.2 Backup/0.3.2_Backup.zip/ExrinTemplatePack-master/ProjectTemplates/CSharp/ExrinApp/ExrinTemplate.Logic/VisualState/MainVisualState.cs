﻿using Exrin.Abstraction;

namespace $safeprojectname$.VisualState
{
    public class MainVisualState : Exrin.Framework.VisualState
    {
        public MainVisualState(IBaseModel model) : base(model)
        {
        }
    }
}
