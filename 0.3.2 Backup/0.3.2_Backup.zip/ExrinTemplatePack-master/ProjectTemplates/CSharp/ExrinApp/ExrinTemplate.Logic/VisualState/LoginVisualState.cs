﻿using Exrin.Abstraction;

namespace $safeprojectname$.VisualState
{
    public class LoginVisualState : Exrin.Framework.VisualState
    {
        public LoginVisualState(IBaseModel model) : base(model)
        {
        }
    }
}
