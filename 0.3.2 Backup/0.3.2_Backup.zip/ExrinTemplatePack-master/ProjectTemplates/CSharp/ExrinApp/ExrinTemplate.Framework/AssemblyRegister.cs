﻿namespace $safeprojectname$
{
    public class AssemblyRegister { }
}
