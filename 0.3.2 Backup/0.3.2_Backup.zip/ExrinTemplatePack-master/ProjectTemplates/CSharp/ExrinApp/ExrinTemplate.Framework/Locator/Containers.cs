﻿namespace $safeprojectname$.Locator
{
    public enum Containers
    {
        Authentication,
        Main
    }
}
