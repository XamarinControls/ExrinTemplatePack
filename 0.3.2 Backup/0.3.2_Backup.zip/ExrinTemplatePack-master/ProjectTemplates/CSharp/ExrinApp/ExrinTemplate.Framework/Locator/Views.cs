﻿namespace $safeprojectname$.Locator.Views
{
    public enum Authentication
    {
        Login
    }

    public enum Main
    {
        Main
    }
}
