﻿using System;

namespace $safeprojectname$.Locator
{
    public enum Stacks
    {
        Authentication = 1,
        Main = 2        
    }
}
