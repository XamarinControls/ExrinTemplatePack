﻿using Exrin.Abstraction;

namespace $safeprojectname$.Abstraction.ModelState
{
    public interface IAuthModelState: IModelState
    {
    }
}
