﻿using Exrin.Abstraction;

namespace $safeprojectname$.Abstraction.Model
{
    public interface IMainModel: IBaseModel
    {
    }
}
