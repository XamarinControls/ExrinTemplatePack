﻿using Exrin.Abstraction;

namespace $safeprojectname$.Abstraction.ModelState
{
    public interface IMainModelState: IModelState
    {
    }
}
