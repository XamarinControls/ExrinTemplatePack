﻿using $safeprojectname$.Base;

namespace $safeprojectname$
{
    public partial class MainView : BaseView
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
