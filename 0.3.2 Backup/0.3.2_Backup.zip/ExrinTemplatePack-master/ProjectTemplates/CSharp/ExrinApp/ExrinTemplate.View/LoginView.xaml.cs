﻿using $safeprojectname$.Base;

namespace $safeprojectname$
{
    public partial class LoginView : BaseView
    {
        public LoginView()
        {
            InitializeComponent();
        }
    }
}
