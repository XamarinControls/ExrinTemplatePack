﻿using Exrin.Abstraction;

namespace $safeprojectname$
{
    public class Bootstrapper : IPlatformBootstrapper
    {
        public void Register(IInjectionProxy injection)
        {
        }
    }
}
